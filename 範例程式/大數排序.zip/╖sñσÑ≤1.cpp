#include<stdio.h>
int main(){
	
	int i,j,Array[5][5];
	for(i=0;i<5;i++){
		for(j=0;j<5;j++){
			scanf("%2d",&Array[i][j]);
		}
	}
	
	printf("\n\n");
	
	for(j=0;j<5;j++){
		for(i=0;i<5;i++){
			printf("%2d ",Array[i][j]);
		}
		printf("\n");
	}
	return 0;
} 
