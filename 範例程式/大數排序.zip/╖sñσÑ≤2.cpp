#include<stdio.h>
#include<string.h>

#define BigIntLen 21
#define Times 5

typedef char digit;

int main(){
	digit bigint[10][BigIntLen];
//	memset(bigint, 0, sizeof(bigint));
	
	int i,j;
	
	for(i = 0; i < Times; i++){
		scanf("%s", bigint[i]);
	}
	
	printf("\n");
	
	for(i = 0; i < Times; i++){
		for(j = 0; j < Times; j++){
			printf("%3d, ", bigint[i][j]);
		}
	}
	printf("\n");
	return 0;
}
