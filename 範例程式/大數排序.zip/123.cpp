#include<stdio.h>
#include<string.h>

#define BigIntLen 21
#define Times 5

typedef char digit;

int main(){
	digit bigint[10][BigIntLen];
	memset(bigint, 0, sizeof(bigint));
	
	digit tmp[10][BigIntLen];
	memset(bigint, 0, sizeof(bigint));
	
	int i,j;
	
	for(i = 0; i < Times; i++){
		scanf("%s", bigint[i]);
	}
	
//	printf("%d",strcmp(bigint[0],bigint[1]));
	
//	for(i = 0; i < Times; i++){
//		for(j = 0; j < Times; j++){
//			if(strlen(bigint[j]) > strlen(bigint[j+1])){
//				strcpy(tmp[j],bigint[j]);
//				strcpy(bigint[j],bigint[j+1]);
//				strcpy(bigint[j+1],tmp[j]);
//			}
//		}
//	}
	
	for(i = 0; i < Times; i++){
		for(j = 0; j < Times; j++){
			if(strlen(bigint[j]) == strlen(bigint[j+1])){
				if(strcmp(bigint[j],bigint[j+1]) == -1){
					strcpy(tmp[j],bigint[j]);
					strcpy(bigint[j],bigint[j+1]);
					strcpy(bigint[j+1],tmp[j]);
				}
			}
		}
	}
	
	printf("\n");
	
	for(i = 0; i < Times+1; i++){
		printf("%s\n", bigint[i]);
	}
	
	return 0;
}
