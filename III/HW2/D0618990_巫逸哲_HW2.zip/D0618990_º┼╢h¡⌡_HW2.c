#include<stdio.h>
#define max 30 

//typedef const int cint;

int main(){
//	cint arr[max] = {1, 50, 8, 64, 654, 30, 28, 26, 24, 22, 20, 2, 4, 6, 9, 10, 29, 27, 25, 23, 21, 11, 13, 15, 17, 19, 18, 16, 14, 12};
//	cint *ptr[max];
//	cint *tmp;

	int arr[max] = {1, 50, 8, 64, 654, 30, 28, 26, 24, 22, 20, 2, 4, 6, 9, 10, 29, 27, 25, 23, 21, 11, 13, 15, 17, 19, 18, 16, 14, 12};
	int *ptr[max];
	
	int  i, j , *tmp;

	for(i = 0; i < max; i++){
		ptr[i] = &arr[i];
	}
	
	for(i = 0; i < max; i++){
		for(j = i; j < max; j++){
			if(*ptr[j] < *ptr[i]){
				tmp = ptr[j];
				ptr[j] = ptr[i];
				ptr[i] = tmp;
			}
		}
	}
	
	for(i = 0; i < max; i++){
		printf("%d ",*ptr[i]);
	}
	
//	for(i = 0; i < max; i++){
//		printf("%d ",arr[i]);
//	}
	
	return 0;
} 
