#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char uchar;

typedef struct bigint{
	unsigned int len;
	uchar *val;
}bint;

bint *newbint(){
	bint *iptr;
	iptr = (bint*)malloc(sizeof(bint));
	memset(iptr, 0, sizeof(bint));
	return iptr;
}

void *set(bint *tar){
	int i;

	tar->val = (uchar*) malloc(sizeof(char));
	for(i = 0; ; i++){
		tar->val = (uchar*)realloc(tar->val, sizeof(char)*(i+1));
		tar->val[i] = getchar(); 
		if(tar->val[i] == '\n'){
			break;
		}
	}
	tar->len = i;
}

void reverse(bint *tar){
	int i, j;
	
	for(i = 0; i < (tar->len)/2; i++){
		j = tar->len-1-i;
		tar->val[i] = tar->val[i] ^ tar->val[j];
		tar->val[j] = tar->val[i] ^ tar->val[j];
		tar->val[i] = tar->val[i] ^ tar->val[j];
	}
}

bint *add(bint *a,bint *b){
	int i,j;
	char temp;
	bint *tar = newbint();

	reverse(a);
	reverse(b);

	if(a->len >= b->len){
		tar->len = a->len+1;
		tar->val = (uchar*)malloc(sizeof(char)*tar->len);
		b->val = (uchar*)realloc(b->val,sizeof(char)*a->len+1);
		
		for(i = b->len; i < a->len; i++){
			b->val[i] = '0';
		}	
	} else {
		tar->len = b->len+1;
		tar->val = (uchar*)malloc(sizeof(char)*tar->len);
		a->val = (uchar*)realloc(a->val,sizeof(char)*b->len+1);	
		
		for(i = a->len; i < b->len; i++){
			a->val[i] = '0';
		}
	}
	
	memset(tar->val, '0', tar->len);
	
	for(i = 0; i < tar->len - 1; i++){
		
		a->val[i] -= '0';
		b->val[i] -= '0';
		
		if((tar->val[i] -'0')+(a->val[i])+(b->val[i]) % 10 != 0){
			tar->val[i+1] += ((tar->val[i] - '0')+(a->val[i])+(b->val[i]))/10;
			tar->val[i] = ((tar->val[i] - '0')+(a->val[i])+(b->val[i]))% 10 + '0';
		} else {
			tar->val[i] += ((a->val[i])+(b->val[i]));
		}
	}

	return tar;
}

void printint(bint *tar){
	
	int i, printCheck = 0;
	
	for(i = tar->len - 1; i >= 0; i--){
		if(tar->val[i] != '0' || printCheck != 0){
			printf("%c",tar->val[i]);
			printCheck = 1;
		}
	}
}

int main(){
	bint *a, *b;
	bint *c = NULL;
	while(1){
		a = newbint();
		b = newbint();
		set(a);
		if(a && a->len == 1 && a->val[0] == '0') break;
		set(b);
		if(c){
			free(c->val);
			free(c);
		}
		c = add(a,b);
		printint(c);
		putchar('\n');
		free(a);
		free(b);
	}
	return 0;
}

