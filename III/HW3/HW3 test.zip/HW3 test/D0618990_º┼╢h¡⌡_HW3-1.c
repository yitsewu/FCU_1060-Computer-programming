#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char uchar;

typedef struct bigint{
	unsigned int len;
	uchar *val;
}bint;

bint *newbint(){
	bint *iptr;
	iptr = (bint*)malloc(sizeof(bint));
	memset(iptr, 0, sizeof(bint));
	return iptr;
}

void reverse(bint *tar){
	int i, j;
		
	for(i = 0; i < (tar->len)/2; i++){
		j = tar->len-1-i;
		tar->val[i] = tar->val[i] ^ tar->val[j];
		tar->val[j] = tar->val[i] ^ tar->val[j];
		tar->val[i] = tar->val[i] ^ tar->val[j];
	}
//	printf("%s",tar->val);
}

void set(bint *tar){
	int i=0;
	
	tar->val = (uchar*)malloc(sizeof(uchar));
	
	for(i = 0;; i++){
		tar->len = i;
		tar->val[i] = getchar();
		tar->val = (uchar*)realloc(tar->val, sizeof(uchar)*(i+1));
//		printf("%d",strlen(tar->val));
		tar->val[i] = '\0';
		if((tar->val[i] == '\n') || (tar->val[i] == '\r')) break;
	}
	
}



bint *add(bint *a, bint *b){
	int i;
	
	bint *tar = newbint();
	
	reverse(a);
	reverse(b);
	
	if(a->len >= b->len){
		tar->val = (uchar*)malloc(sizeof(a->val) + sizeof(uchar));
		memset(tar->val, 0, sizeof(tar->val));
		cb = (uchar*)realloc(tar->val, sizeof(uchar)*(a->len+1));
//		b->val = (uchar*)realloc(tar->val, sizeof(uchar)*(a->len+1));
//		for(i = b->len; i <= a->len; i++){
//			b->val[i] = 0;
//		}
		tar->len = a->len;
	} else {
		tar->val = (uchar*)malloc(sizeof(b->val) + sizeof(uchar));
		memset(tar->val, 0, sizeof(tar->val));
		a->val = (uchar*)realloc(tar->val, sizeof(uchar)*(b->len+1));
		tar->len = b->len;
	}
	
	for(i = 0; i < tar->len; i++){
//		printf("%c %c\n", a->val[i], b->val[i]);
		tar->val[i] += (a->val[i]-'0') + (b->val[i]-'0');
//		printf("%d\n", tar->val[i]);
		if(tar->val[i]/10 != 0){
///			printf("IN %d %d\n", tar->val[i+1], tar->val[i]);
			tar->val[i+1] = tar->val[i]/10;
//			printf("/10 %d %d\n", tar->val[i+1], tar->val[i]);
			tar->val[i] %= 10;
//			printf("%%10 %d %d\n", tar->val[i+1], tar->val[i]);
		}
	}
	
//	for(i = 0; i < tar->len; i++){
//		printf("%d",tar->val[i]);
//	}
	
	
	return tar;

}

void printbint(bint *tar){
	int i;
	reverse(tar);
	for(i = 0; i < tar->len; i++){
		printf("%d",tar->val[i]);
	}
//	printf("!\n");
}

int main(){
	bint *a, *b;
	bint *c = NULL;
	while(1){
		a = newbint();
		b = newbint();
		c = NULL;
		
		set(a);
		if(a && a->len == 1 && a->val[0] == '0') break;
		set(b);
		if(c){
			free(c->val);
			free(c);
		}
		c = add(a, b);
		printbint(c);
		putchar('\n');
		free(a);
		free(b);
	}
	return 0;
}
