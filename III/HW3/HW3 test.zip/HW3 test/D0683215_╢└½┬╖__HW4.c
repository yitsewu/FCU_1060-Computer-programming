#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct Bint{
	unsigned int len;
	unsigned char* val;
}Bint;

Bint* set(Bint* num){
	int n;
	num = (Bint*) malloc(sizeof(Bint));  //����`�N ���ѱ�GG 
	num->val = (unsigned char*) malloc(sizeof(char)); //�����t�Ŷ����j�� 
	for(n = 0;;n++){
		num->val = (unsigned char*) realloc(num->val,(n+1)*sizeof(char));
		num->val[n] = getchar(); 
		if(num->val[n] < '0' ||num->val[n] > '9'){
			num->val[n] = '\0';
			break;
		}
	}
	num->len = n;
	return num;
	free(num->val);
	free(num);
}
Bint* add(Bint* a,Bint* b){
	int n;
	char temp;
	Bint* c = (Bint*) malloc(sizeof(Bint*));
	for(n = 0;n < (a->len)/2;n++){
		temp = a->val[n];
		a->val[n] = a->val[((a->len)- 1) - n];
		a->val[((a->len) - 1 - n)] = temp;
	}
	for(n = 0;n < (b->len)/2;n++){
		temp = b->val[n];
		b->val[n] = b->val[((b->len) - 1)-n];
		b->val[((b->len) - 1)-n] = temp;
	}
	//======���t�Ŷ��øɹs================= 
	if(a->len >= b->len){
		c->len = a->len+1;
		c->val = (unsigned char*) malloc(c->len);
		b->val = (unsigned char*) realloc(b->val,a->len);
		for(n = b->len;n < a->len;n++){
			b->val[n] = '0';
		}
		for(n = 0;n < c->len;n++){
			c->val[n] = '0';
		}
	}else{
		c->len = b->len+1;
		c->val = (unsigned char*) malloc(c->len);
		a->val = (unsigned char*) realloc(a->val,b->len);
		for(n = a->len;n < b->len;n++){
			a->val[n] = '0';
		}
		for(n = 0;n < c->len;n++){
			c->val[n] = '0';
		}
	}
	//===================================
	for(n = 0;n < c->len - 1;n++){
		if((c->val[n]-'0')+(a->val[n] - '0')+(b->val[n] - '0') >= 10){
			c->val[n+1] += ((c->val[n] - '0')+(a->val[n] - '0')+(b->val[n] - '0'))/10;
			c->val[n] = ((c->val[n] - '0')+(a->val[n] - '0')+(b->val[n] - '0')) % 10+ '0';
		}else{
			c->val[n] += ((a->val[n] - '0')+(b->val[n] - '0'));
		}
	}
	return c;
}
void printint(Bint* c){
	int n,t;
	for(n = c->len - 1;n >= 0;n--){
		if(c->val[n] > '0'&& c->val[n] < '9'){
			for(t = n;t >= 0;t--){
				printf("%c",c->val[t]);
			}
			break;
		}
	}
	free(c->val);
	free(c);
}
int main(){
	Bint* a;
	Bint* b;
	Bint* c = NULL;
	while(1){
		a = set(a);
		if(a->len == 1 && a->val[0] == '0') break;
		b = set(b);
		c = add(a,b);
		printint(c);
		printf("\n");
	}
	return 0;
}

