#include<stdio.h>

int main(){
	
	int tmp, i, a[5] = {1, 2, 3, 4, 5};
	for(i = 0; i < 5/2; i++){
		tmp = a[i];
		a[i] = a[5-1-i];
		a[5-1-i] = tmp;
	}
	for(i = 0; i < 5; i++){
		printf("%d",a[i]);
	}

	return 0;
} 
