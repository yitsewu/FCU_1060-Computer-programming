#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct bigint{
	unsigned int len;
	unsigned int space_size;
	unsigned char *val;
}bint;

typedef unsigned char uchar;

bint *newbint(){
	bint *newnum = (bint*) malloc(sizeof(bint));
	memset(newnum, 0, sizeof(newnum));
	return newnum;
}

void reverse(bint *tar){
	int i;
	char temp;
	for(i = 0;i < (strlen(tar->val) / 2);i++){
		temp = tar->val[strlen(tar->val) - i - 1];
		tar->val[strlen(tar->val) - i - 1] = tar->val[i];
		tar->val[i] = temp;
	}
}

void set(bint *tar){
	int i;
	tar->len = 0;
	tar->val = (char*) malloc(sizeof(char));
	for(i = 0;i >= 0;i++){
		tar->len++;
		scanf("%c",&tar->val[i]);
		tar->val = (char*) realloc(tar->val, sizeof(char) * (i + 1));
		if(tar->val[i] == '\n'){
			tar->val[i] = '\0';
			break;
		}
	}
	
}

bint *add(bint *a, bint *b){
	int c, d, e, i;
	char one;
	bint *temp = newbint();
	temp->val = (char*) malloc(sizeof(char));
	if(strlen(a->val) > strlen(b->val)){
		c = strlen(a->val);
		d = strlen(b->val);
		temp->val = (char*) realloc(temp->val, sizeof(char) * (c + 1));
		b->val = (char*) realloc(b->val, sizeof(char) * (c + 1));
		for(i = d;i < c;i++){
			b->val[i] = '0';
		}
	}
	else{

		c = strlen(b->val);
		d = strlen(a->val);
		temp->val = (char*) realloc(temp->val, sizeof(char) * (c + 1));
		a->val = (char*) realloc(a->val, sizeof(char) * (c + 1));
		for(i = d;i < c;i++){
			a->val[i] = '0';
		}
	}

	for(i = 0;i < c;i++){
		one = ((a->val[i] - '0') + (b->val[i] - '0'));
		if(one / 10 != 0){
			temp->val[i] = (one % 10 + '0');
			b->val[i + 1] += 1;
		}
		else{
			temp->val[i] = one + '0';
		}
	}
	
	return temp;
}

void printbint(bint *tar){
	int i;

	for(i = strlen(tar->val);i >= 0;i--){
		if(tar->val[i] >= '0' && tar->val[i] <= '9'){
			printf("%c",tar->val[i]);
		}
	}
}

int main(){
	bint *a = newbint(), *b = newbint();
	bint *c = NULL;
	while(1){
		set(a);
		if(a && a->len == 1 && a->val[0] == '0') break;
		set(b);
		reverse(a);
		reverse(b);
		if(c){
			free(c->val);
			free(c);
		}
		c = add(a, b);
		printbint(c);
		putchar('\n');
	}
	free(c);
	return 0;
}
