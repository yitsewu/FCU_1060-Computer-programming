#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct bigint{
	unsigned int len;
	unsigned int space_size;
	unsigned char *val;
}bint;

typedef unsigned char uchar;

bint *newbint(){
	bint *iptr;
	iptr = (bint*)malloc(sizeof(bint));
	memset(iptr, 0, sizeof(iptr));
	return iptr;
}

void set(bint *tar){
	int i=0;
	
	tar->val = (char*)malloc(sizeof(char));
	  
	while((tar->val[i-1] != '\n' ) && (tar->val[i-1] != '\r' ) && (tar->val[i-1] != ' ' )){
	
		tar->val = (char*)realloc(tar->val, sizeof(char)*i+1);
		printf("%d ",strlen(tar->val));
		tar->val[i] = getchar();
		tar->len = i;
		if(tar->val[i] == 10) break;
		i++;
	}
	
}


void reverse(bint *tar){
//	int i, j;
//		
//	for(i = 0; i < tar->len/2; i++){
//		j = tar->len-1-i;
//		tar->val[i] = tar->val[i] ^ tar->val[j];
//		tar->val[j] = tar->val[i] ^ tar->val[j];
//		tar->val[i] = tar->val[i] ^ tar->val[j];
//	}
//	
}

bint *add(bint *a, bint *b){
	int i, j;
	
	bint *tar = newbint();
	
	printf("%d",a->len);

	
	if(a->len > b->len){
		tar->val = (char*)malloc(sizeof(a->val) + sizeof(char));
		j = a->len;
	} else {
		tar->val = (char*)malloc(sizeof(b->val) + sizeof(char));
		j = b->len;
	}
	
	for(i = 0; i < j+1; i++){
		tar->val[i] = a->val[i] + b->val[i];
	}
	for(i = 0; i < j+1; i++){
		tar->val[i+1] = tar->val[i]/10;
		tar->val[i] %= 10;
	}
	
	return tar;
	
}

void printbint(bint *tar){
	
}

int main(){
	bint *a = newbint(), *b = newbint();
	bint *c = NULL;
	
	while(1){
		set(a);
		if(a && a->len == 1 && a->val[0] == 0) break;
		set(b);
		printf("hi");
		if(c){
			free(c->val);
			free(c);
		}
		c = add(a, b);
		printbint(c);
		putchar('\n');
	}
	return 0;
}
