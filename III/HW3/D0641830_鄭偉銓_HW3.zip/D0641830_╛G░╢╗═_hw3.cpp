#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct bigint{
	 int len;
	 unsigned char* val;	 
}bint;

bint* newbint(){
	bint* x;
	x = (bint*)malloc(sizeof(bint));
	memset(x, 0,sizeof(bint));
	return x;
}

void reverse(bint* tar){
	int i;

	for(i=0;i<tar->len/2;i++){
		tar->val[i] ^= tar->val[tar->len-i-1];
		tar->val[tar->len-i-1] ^= tar->val[i];
		tar->val[i] ^= tar->val[tar->len-i-1];
	}
}

void set(bint* tar){
	int i=0;
	
 	tar->val = (unsigned char*)malloc(sizeof(unsigned char));
 	
 	do{
  	tar->val = (unsigned char*)realloc(tar->val,sizeof(char)*(i+1));
 	tar->val[i] = getchar();
 	i++;
 	}while(tar->val[i-1] != '\n' );
 	tar->len = i-1;
}

int main(){
	bint* a = newbint(), *b = newbint();
	bint* c = NULL;

	while(1){
		a = newbint();
		b = newbint();
		
		set(a);
		if(a->len == 1 && a->val[0] == '0') break;
		set(b);
		if(c){
			free(c->val);
			free(c);
		}
		
		//�ڪ�!�ŧi�� !
		int i,max,plus=0,yo=0,carry=0;;
		max = b->len;
		if(a->len > b->len) max=a->len;
		 char arr[max+1]={0};
	
	
		reverse(a);
		reverse(b);
		
		for(i=0;i<max;i++){
		
			if(a->val[i]<48||a->val[i]>57){
				arr[i]=b->val[i]+plus;
			}
			else if(b->val[i]<48||b->val[i]>57){
				arr[i]=a->val[i]+plus;
			}
			else{
				arr[i]=a->val[i]+b->val[i]-48+plus;
			}
			plus = 0;
			//�i�� 
			if(arr[i]>57){
				plus=1;
				arr[i]-=10;
				carry=1;;
			}
			
		if(	i==max-1&&plus==1){
				arr[i+1]='1';
			yo=1;
			}
		}
			
		if(yo==1){
			for(i=0;i<(max+yo)/2;i++){
			arr[i] ^= arr[max-i];
			arr[max-i] ^= arr[i];
			arr[i] ^= arr[max-i];
			}
		}
		else{
			for(i=0;i<(max)/2;i++){
			arr[i] ^= arr[max-i-1];
			arr[max-i-1] ^= arr[i];
			arr[i] ^= arr[max-i-1];
			}
		}

		for(i=0;i<max+carry;i++){
			printf("%c",arr[i]);
		}

		printf("\n");
		
		memset(arr,0,max);
		free(a);
		free(b);	
	}
	return 0;
}
