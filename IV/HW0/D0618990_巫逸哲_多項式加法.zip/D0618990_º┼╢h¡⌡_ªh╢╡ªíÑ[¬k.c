#include<stdio.h>
#include<stdlib.h>
#include<windows.h>

typedef struct NODE{
	int num;
	int power;
	struct NODE *next;
}NODE;

void newnode(NODE **dest, int num, int power){
	NODE *current = *dest;
	NODE *new_node;
	
	new_node = (NODE*)malloc(sizeof(NODE));
	new_node->num = num;
	new_node->power = power;
	new_node->next = NULL;
	
	while(1){
		if(*dest == NULL){
			*dest = new_node;
			break;
		} else {
			if(current->next == NULL){
				current->next = new_node;
				break;
			} else {
				current = current->next;
			}
		}
	}
}

void printlist(NODE *print){
	NODE *current = print;
	
	while(1){
		if(current == NULL) break;
		if(current->num != 0){
			if(current != print && current->num > 0){
				printf("+"); 
			}
			printf("%d", current->num);
			if(current->power != 0){
				printf("x^");
				printf("%d", current->power);
			}
		}
		current = current->next;
	}
}

int SearchNode(NODE *node, int power){
	NODE *current;
	current = node;
	
	while(current != NULL){
		if(current -> power == power){
			return current -> num;
			break;
		}
		current = current -> next;
	}
	return 0;
}


int main(){
	NODE *A = NULL;
	NODE *B = NULL;
	NODE *Ans = NULL;
	
	int num, power, top = 0;
	char x, y;
	
	printf("---------------�h�����[�k---------------\n\n");
	printf("-----------------��  ��-----------------\n\n\n");
	printf("��J�����ɡA���[�W�@�� 0 �@������\n");
	printf("�h���� :   8x^14-3x^10+10x^6\n"); 
	printf("�d�ҿ�J : 8x^14-3x^10+10x^6 0\n\n");
	printf("��J�����`�ƮɡA�����[�W�@�� 0 �A�A�[�W�@�� 0 �@������\n");
	printf("�h���� :   3x^14+2x^8+1\n"); 
	printf("��J�榡 : 3x^14+2x^8+1 0 0\n\n");
	printf("------------���������۰ʸ���------------\n");
	Sleep(5000);
	system("CLS");
	
	
	printf("---------------�h�����[�k---------------\n\n");
	printf("�h���� 1 : ");
	while(1){
		num = 0; power= 0; x = 0; y = 0;
		
		scanf("%d",&num);
		if(num == 0) break;
		scanf("%c %c",&x,&y);
		if(x != '0' && y != '0'){
			scanf("%d",&power);
			if(power > top) top = power;
		} else {
			power = 0;
			newnode(&A, num, power);
			break;
		}
		newnode(&A, num, power);
	}
	printf("\n");
	
	fflush(stdin);
	
	printf("�h���� 2 : ");
	while(1){
		num = 0; power= 0; x = 0; y = 0;
		
		scanf("%d",&num);
		if(num == 0) break;
		scanf("%c %c",&x,&y);
		if(x != '0' && y != '0'){
			scanf("%d",&power);
			if(power > top) top = power;
		} else {
			power = 0;
			newnode(&B, num, power);
			break;
		}
		newnode(&B, num, power);
	}
	
	for(;top >= 0;top--){
		newnode(&Ans, (SearchNode(A, top) + SearchNode(B, top)), top);
	}
	
	printf("\n");
	printf("Answer   : ");
	printlist(Ans);
	
	return 0;
}
