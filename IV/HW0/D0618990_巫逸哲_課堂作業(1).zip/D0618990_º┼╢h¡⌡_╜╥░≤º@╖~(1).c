#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define MAX_QUEUE 50

int CircularQueue[MAX_QUEUE];

void GenerateNumberCards(int input){
	int i;
	
	memset(CircularQueue, 0, sizeof(CircularQueue));
	
	for(i = 0; i < input ; i++){ 
		CircularQueue[i] = i + 1;
	}
}

void PrintCard(int input, int rear){
	
	int i, front = 0;
	
	printf("Discarded cards: ");
	
	for(i = 0; i < input; i++){
		
		printf(" %d ", CircularQueue[front]);
		
		rear = (rear + 1) % input;
		
		CircularQueue[rear] = CircularQueue[(front+1) % input];
		front = (front + 2) % input;
		
		if(front == rear){
			printf("\n");
			printf("Remaining card: %d\n", CircularQueue[front]);
			break;
		}
	}
}

void JustDoIt(int input){
	int rear = input - 1;
	
	GenerateNumberCards(input);
	PrintCard(input,rear);
}

int main(){
	
	int input;
	
	while(1){
		input = 0;
		scanf("%d",&input);
		
		if(input == 0){
			return 0;
		} else if(input == 1){
			printf("Discarded cards: empty\n");
			printf("Remaining card: 1\n");
		} else if(input > 50){
			printf("Over 50!!!\n");
		} else {
			JustDoIt(input);
		}
		
	}
	
}
