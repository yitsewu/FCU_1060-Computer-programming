#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/* �̤j��Ʀr���J */
#define MAX 50


char stack[MAX];

int top = -1;

void push(char x){
    stack[top += 1] = x;
}

char pop(){
    if(top == -1){
    	return -1;
	} else {
    	return stack[top--];
	}
}

int priority(char x){
    if(x == '('){
    	return 0;
	}
    if(x == '+' || x == '-'){
    	return 1;
	}
    if(x == '*' || x == '/'){
    	return 2;
	}
}

int main(){

    char Input[MAX],*input, x;
    
    printf("Infix to Postfix\n");
	printf("----------------\n\n");
	printf("Use \"exit\" to end this program\n\n");
	
    while(1){
    	memset(Input, 0, sizeof(Input));
    	
		printf("Infix 	: ");
	    scanf("%s",Input);
		if(strcmp(Input,"exit") == 0) return 0;
		
		printf("Postfix	: ");
		
	    for(input = Input; ; input++){
			if(*input == '\0'){
				break;
			} else if(*input >= '0' && *input <= '9'){
	        	printf("%c",*input);
			} else if(*input == '('){
	        	push(*input);
			} else if(*input == ')'){
	            while((x = pop()) != '('){
	            	printf("%c", x);
				}
	        } else {
	            while(priority(stack[top]) >= priority(*input)){
	            	printf("%c",pop());
				}
	            push(*input);
	        }
	    }
	    
	    while(top != -1){
	        printf("%c",pop());
	    }
	    
	    printf("\n\n");
	}
	
    return 0;
}



/* �ѦҨӷ�: https://ppt.cc/fUEbex */
