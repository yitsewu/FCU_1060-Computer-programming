#include "fact.h"
#include "gcdlcm.h"

fact fadd(fact addition, fact added){
	fact result = {0, 0};
	if(addition.deno != added.deno){
		int add_lcm = lcm(addition.deno, added.deno);
		result.nume = (addition.nume * (add_lcm / addition.deno) + added.nume * (add_lcm / added.deno));
		result.deno = add_lcm;
	}
	else{
		result.nume = addition.nume + added.nume;
		result.deno = addition.deno;
	}
	return result;
}

void factprint(fact source);

