#ifndef FACT_H
#define FACH_H

#include <stdio.h>

typedef struct fraction{
	int nume;	//���l
	int deno;	//����
}fact;

//�ɤW�[�k�ŧi(10%)
fact fadd(fact,fact);
int gcd(int,int);
int lcm(int,int);

static fact fsub(fact reduced, fact substraction){ 		//���ƴ�k�A�q���۴�L����²(20%) 
	fact ans;
	int time;
	time = reduced.deno*substraction.deno;
	ans.deno = time;
	ans.nume = reduced.nume*(time/reduced.deno)-substraction.nume*(time/substraction.deno); 
	return ans;
}
		
static fact fmulti(fact multiplicand, fact multiplier){    //���ƭ��k�A�L����²(20%)
	fact ans;
	ans.nume = multiplicand.nume * multiplier.nume;
	ans.deno = multiplicand.deno * multiplier.deno;
	return ans;
}
	
static fact fdivis(fact dividend, fact divisor){		    //���ư��k�A�L����²(20%)
	fact ans;
	ans.nume = dividend.nume * divisor.deno;
	ans.deno = dividend.deno * divisor.nume;
	return ans;
}	
		
static fact ftimes(fact source, int times){                //���ƭ��H���(10%)
    fact ans;
    ans.nume = source.nume*times;
    ans.deno = source.deno*times;
    return ans;
}
				
static fact ftrans(fact source){                           //�˼�(10%)
	fact ans;
	ans.deno = source.nume;
	ans.nume = source.deno;
	return ans;
}	
						
static fact freduce(fact source){                          //���Ƥ�²(10%)
	fact ans;
    int de;
	de = gcd(source.deno,source.nume);
	ans.nume = source.nume/de;
	ans.deno = source.deno/de;
	return ans;
}

static void factprint(fact source){
	printf("%d/%d\n",source.nume,source.deno);
}	
#endif
