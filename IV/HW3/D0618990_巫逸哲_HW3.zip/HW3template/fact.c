#include "fact.h"
#include "gcdlcm.h"

/* ���ƥ[�k */
fact fadd(fact addition, fact added){
	fact result = {0, 0};
	
	if(addition.deno != added.deno){
		int add_lcm = lcm(addition.deno, added.deno);
		result.nume = (addition.nume * (add_lcm / addition.deno) + added.nume * (add_lcm / added.deno));
		result.deno = add_lcm;
	} else {
		result.nume = addition.nume + added.nume;
		result.deno = addition.deno;
	}
	
	return result;
}

/* ���ƴ�k */
fact fsub(fact reduced, fact substraction){
	fact result = {0, 0};
	
	if(reduced.deno != substraction.deno){
		int add_lcm = lcm(reduced.deno, substraction.deno);
		result.nume = (reduced.nume * (add_lcm / reduced.deno) - substraction.nume * (add_lcm / substraction.deno));
		result.deno = add_lcm;
	} else {
		result.nume = reduced.nume - substraction.nume;
		result.deno = reduced.deno;
	}
	
	return result;
}

/* ���ƭ��k */
fact fmulti(fact multiplicand, fact multiplier){
	fact result = {0, 0};
	
	result.nume = multiplicand.nume * multiplier.nume;
	result.deno = multiplicand.deno * multiplier.deno;
	
	return result;
}

/* ���ư��k */
fact fdivis(fact dividend, fact divisor){
	fact result = {0, 0};
	fact tmp = {0, 0};
	
	tmp = ftrans(divisor);
	
	result.nume = dividend.nume * tmp.nume;
	result.deno = dividend.deno * tmp.deno;
	
	return result;
}

///* ���ƭ��H��� */
//fact ftimes(fact source, int times){
//	fact tmp = {times, 1};;
//	fact result = {0, 0};
//	
//	result.nume = source.nume * tmp.nume;
//	result.deno = source.deno * tmp.deno;
//	
//	return result;
//}

/* ���l�����P���H��� �X��(��main.c�����G�@��) */
fact ftimes(fact source, int times){
	fact tmp = {times, times};;
	fact result = {0, 0};
	
	result.nume = source.nume * tmp.nume;
	result.deno = source.deno * tmp.deno;
	
	return result;
}

/* �˼� */
fact ftrans(fact source){
	
	fact result = {source.deno, source.nume};
	
	return result;
}

/* ���Ƥ�² */
fact freduce(fact source){
	int tmp;
	
	tmp = gcd(source.nume, source.deno);
	
	fact result = {source.nume/tmp, source.deno/tmp};
	
	return result;
}

/* �L�X���� */
void factprint(fact source){
	printf("%d/%d\n", source.nume, source.deno);
}
