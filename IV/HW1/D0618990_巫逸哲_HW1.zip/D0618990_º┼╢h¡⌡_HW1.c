#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 5

/* �ŧi���c */
typedef struct node{
	int num;
	struct node *next;
	struct node *prev;
}NODE;

/* �s�W�@�`�I */
NODE *GenerateNode(int num){
	NODE *new_node;
	new_node = (NODE*)malloc(sizeof(NODE));
	new_node->num = num;
	new_node->next = NULL;
	return new_node;
}

int main(){
	NODE *head = NULL, *curr, *current;
	int i = 0, input[MAX], num;
	int empty_flag = 0, popcheck_flag = 0 ,check_flag = 0, pushorpop_flag = 0, result_flag = 0;
	
	memset(input, 0, sizeof(input));
	
	/* ��J�ܼ� */
	for(i = 0; i < MAX; i++){
		scanf("%d",&input[i]);
	}
	
	for(i = 0 ;;){
		if(head == NULL && i != MAX){
			pushorpop_flag = 0;
			head = GenerateNode(input[i]);
			current = head;
			num = current->num;
			i++;
		} else if(current->num > input[i] && i != MAX){
			current->next = GenerateNode(input[i]);
			current->next->prev = current;
			current = current->next;
			num = current->num;
			i++;
		} else {
			pushorpop_flag = 1;
			popcheck_flag++;
			num = current->num;
			
			if(current == head){
				free(current->next);
				empty_flag = 1;
				head = NULL;
			} else {
				current = current->prev;
				free(current->next);
				current->next = NULL;
			}
			
			if(num == popcheck_flag){
				check_flag++;
			} else {
				result_flag = 1;
			}
		}
		
		/* ��X */
		(pushorpop_flag == 0)? printf("push : %2d\n",num):printf("pop  : %2d\n",num);
		
		printf("stake : �U");
		
		curr = head;
			
		while(empty_flag == 0){
			printf("%2d ", curr->num);
			curr = curr->next;
			
			if(curr == NULL) break;
		}
		
		if(empty_flag == 1){
			printf(" empty ");
			empty_flag = 0;
		}
		
		printf("�U\n\n");
		
		if(check_flag == 5 || result_flag == 1) break;
	}
	
	(check_flag == 5)? printf("SUCCEED"):printf("FAILED");
	
	return 0;
}
