#include<stdio.h>
#include<stdlib.h>
#include<string.h>

/* �ŧi���c */
typedef struct Node{
	int num;
	struct Node *prev;
	struct Node *next;
}NODE;

NODE* GenerateNode(int num){
	NODE *new_node;
	new_node =(NODE*)malloc(sizeof(NODE));
	new_node->num = num;
	new_node->next = NULL;
	new_node->prev = NULL;
	return new_node;
}

int main(){
	NODE *head, *current, *stack;
	int input[5], i, j, popnum=0;
	
	for(i = 0; i < 5; i++){
		scanf("%d",&input[i]);
	}
	
	head = GenerateNode(input[0]);//�Ĥ@�� 
	printf("push�G%d\n",head->num);
	current = head;
	stack = head;
	printf("stack�G�U");
	while(stack != NULL){
		printf(" %d ",stack->num);
		stack = stack->next;
	}
	printf("�U\n");
	
	for(i=1;i<5;i++){
		for(j=i;j>=0;j--){
			if(current->num > input[i]){
				current->next = GenerateNode(input[i]);//�ĤG�� 
				current->next->prev = current;
				current = current->next;
				printf("push�G%d\n",current->num);			
				stack = head;
				printf("stack�G�U");
				while(stack != NULL){
					printf(" %d ",stack->num);
					stack = stack->next;
				}
				printf("�U\n");	
				break;
			}
			else{
				printf("pop�G%d\n",current->num);
				
				popnum = current->num;
				if(current->prev == NULL){
					break;
				}
				current = current->prev;
							
				current->next =NULL;
				stack = head;
				printf("stack�G�U");
				while(stack != NULL){
					printf(" %d ",stack->num);
					stack = stack->next;
				}	
				printf("�U\n");
			}
			
		}
		if(current->num < popnum){
			break;
		}
		if(current->prev == NULL){
			printf("stack�G�Uempty�U\n");
			break;
		}
	}

	if(i==5){
		while(1){
			printf("pop�G%d\n",current->num);
			current = current->prev;
			if (current == NULL){
				printf("stack�G�U empty �U\n");
				break;
			}
			free(current->next);
			current->next = NULL;
	
			printf("stack�G�U");
			stack = head;
			while(stack != NULL){
				printf(" %d ",stack->num);
				stack = stack->next;
			}
			printf("�U\n");
		}
		printf("SUCCEED\n");
	}
	else{
		printf("FAILED\n");
	}
	return 0;
}
