#include<stdio.h>
#define MAX 100000
int judge(char array[MAX], int current, FILE *ouptr){
	int cunt = 1;
	char temp[MAX];
	while(array[current] != '\0'){
		cunt = 1;
		temp[0] = array[current++];
		
		if(temp[0] == array[current]){
			cunt = 2;
			while(temp[0] == array[++current]){
				cunt++;
			}
			fprintf(ouptr, "r%d%c", cunt, temp[0]);			
		} else{
			temp[cunt++] = array[current];
			
			while(temp[cunt-1] != array[++current]){
				temp[cunt++] = array[current];
			}
			current--;
			temp[--cunt] = '\0';
			cunt = 0;
			fprintf(ouptr, "n%d%s",cunt , temp);
		}
	}
}

int main(){
	char array[MAX];
	int current = 0;
	FILE *inptr, *ouptr;
	ouptr = fopen("output.txt", "w");
	inptr = fopen("input.txt", "r");
	
	fscanf(inptr, "%s", array);
	judge(array, current, ouptr);
	
	fclose(inptr);
	fclose(ouptr);
	return 0;
}
